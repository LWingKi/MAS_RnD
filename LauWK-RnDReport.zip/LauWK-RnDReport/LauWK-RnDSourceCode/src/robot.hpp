#ifndef ROBOT_HPP
#define ROBOT_HPP

namespace KDL{
class Chain;
Chain Kinova_gen3();
Chain Create_gen3();
}

#endif